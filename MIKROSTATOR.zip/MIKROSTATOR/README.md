# MIKROSTATOR
MIKROSTATOR - Mikrotik Administrator
Versi beta (Senin, 16 Mei 2016)
Youtube : youtube.com/richadavianto
Blog : mikrostator.aviantorichad.com
Email to : aviantorich@gmail.com
MIKROSTATOR, sebuah aplikasi berbasis web yang dibuat berdasarkan kebutuhan untuk manajemen pengguna pada sebuah jaringan internet sederhana berbasis router MIKROTIK.

Change log
MIKROSTATOR versi beta (Senin, 16 Mei 2016):
Komposisi:

Mikrotik API PHP class (Denis Basta)
Bootstrap
PHP Framework CodeIgniter-2.2-stable
Mysql
Jquery
Fitur:

Tambah Jam
Transfer Menit
Real time user online (sesuai interval)
Manajemen User
Restore waktu/jam online ketika 'session time' te-Reset
Log MIKROTIK
Log MIKROSTATOR
Kalkulator sederhana
Auto Backup user online ke db
Toggle Real time user online (sesuai interval)
Toggle Auto Backup user online ke db
Show User Profile
Show DHCP Server Leases
Delete Queue Simple
Reboot & Shutdown Router
Laporan harian, bulanan, tahunan, semua tahun
Konfigurasi login router MIKROTIK
Konfigurasi login MIKROSTATOR
Tambah Transaksi lain
Background MAC Address
MIKROSTATOR versi alpha 3 (Kamis, 07 Jan 2016):
Komposisi:

Mikrotik API PHP class (Denis Basta)
Bootstrap
PHP Native 'ala kadarnya'
Mysql
Jquery
Fitur:

Tambah Jam
Transfer Menit
Real time user online (sesuai interval)
Manajemen User
Restore waktu/jam online ketika 'session time' te-Reset
Log MIKROTIK
Log MIKROSTATOR
Kalkulator sederhana
Auto Backup user online ke db
