<!DOCTYPE html>
<head>
	<link rel="shortcut icon" type="x-icon" href="<?php echo base_url('assets/img/favicon.png') ?>" />
	<title>Play Now - MIKROSTATOR</title>
	<style>
		body{background:#222;color:#777;}
		
	</style>
</head>
<body>
<?php
$audio = 'Shot.mp3';
?>
	
	<h2 style="position:absolute;top:0;left:0;text-align:center;font-family:arial;text-align:center;width:100%;color:#777;font-size:18px;"><?php echo $audio; ?></h2>
	<object height=100%; data="<?php echo base_url('assets/mp3/'.$audio) ?>" style="position:absolute;bottom:0;left:0;width:100%;text-align:center;display:block;;"></object>
</body>
<!--
--- automaBELL V.1, cd:20140301, cn:#flappyBELL
--- created date : 01-Mar-2014
--- author : Richad Avianto
--- email : aviantorich@gmail.com
--- blog : aviantorichad.blogspot.com
--- website : warungkost.com
--- Note : Gunakan dengan bijak aplikasi ini, 
--- silahkan memodifikasi sesuai kebutuhan anda dengan tidak mengubah pembuat awal aplikasi ini, 
--- jika anda mengalami kesulitan silahkan kontak email saya 
--- atau anda bisa menghubungi saya pada kontak yang sudah saya sediakan
--- untuk kondisi yang memungkinkan penghapusan nama saya silahkan meminta ijin saya terlebih dahulu.
-->
</html>