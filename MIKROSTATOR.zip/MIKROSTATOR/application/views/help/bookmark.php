<script>
    function once_load() {
        
    }
    
    once_load();
</script>
<!--HEADER-->
<div class="header">
    <!--TITLE--><center style="margin-bottom:-20px;"><h1><span style="font-family:Arial;font-weight:bold;"><span style="color:#009988;">WEB</span> FAVORIT</span></h1></center><!--END TITLE-->
    <!--DESCRIPTION--><!-- <center><h2><span style="font-size:11px;color:#008899;">..::: PENGGUNA RTPAPAT.NET :::...</span></h2></center> --><!--END DESCRIPTION-->
</div>
<div class="content" style="text-align: center">
    <style>
				.dLink{background:#00aadd;padding:10px 0;width:100%;max-width:240px;margin-bottom:5px;margin-top:0px;display:inline-block;text-align:left;}
				.dLink:hover{background:#FF2626;}
				.dLink a{color:#fff;padding:10px;width:220px;font-weight:bold;font-size:18px;width:100%;}
				.dLink a:hover{background:#D90000;border-radius:0px 25px 25px 0;}
				
				.dCaption{background:#333;margin-bottom:10px;width:100%;padding:15px;margin-left:-10px;margin-top:-10px;}
				.bCari{background:#006699;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bGame{background:#222222;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bBerita{background:#990000;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bSosial{background:#0040FF;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bEmail{background:#660033;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bBlog{background:#0000D9;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bTv{background:#00B359;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bMp3{background:#004000;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bPulsa{background:#000000;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bVideo{background:#B30000;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bForum{background:#006CD9;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bKamus{background:#FF8000;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				.bToko{background:#00B3B3;margin-bottom:10px;width:100%;padding:5px;margin-left:-10px;margin-top:-10px;}
				</style>
				<div class="dLink" style="background:#00aadd;"><a href="http://google.com"><span style="font-size:8px;" class="bCari">[cari]</span> Google</a></div>
				<div class="dLink" style="background:#00ddaa;"><a href="http://poki.com"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 1</a></div>
				<div class="dLink" style="background:#aadd00;"><a href="http://games.co.id"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 2</a></div>
				<div class="dLink" style="background:#66aa00;"><a href="http://permainan.co.id"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 3</a></div>
				<div class="dLink" style="background:#008800;"><a href="http://www.games.com"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 4</a></div>
				<div class="dLink" style="background:#00dd00;"><a href="http://www.cartoonnetwork.com/games"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 5</a></div>
				<div class="dLink" style="background:#0000dd;"><a href="http://www.hasbro.com/en-us/games"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 6</a></div>
				<div class="dLink" style="background:#003388;"><a href="http://friv.com/"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 7</a></div>
				<div class="dLink" style="background:#443388;"><a href="http://a10.com/"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 8</a></div>
				<div class="dLink" style="background:#00D900;"><a href="http://www.bored.com/games/"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 9</a></div>
				<div class="dLink" style="background:#ff73b9;"><a href="http://www.ugamezone.com/game/tags/"><span style="font-size:8px;" class="bGame">[game]</span> Game Online 10</a></div>
				<div class="dLink" style="background:#ddaa00;"><a href="http://chess.com"><span style="font-size:8px;" class="bGame">[game]</span> Catur Online</a></div>
				<div class="dLink" style="background:#dd8833;"><a href="http://dreamcarracing.com"><span style="font-size:8px;" class="bGame">[game]</span> Dream Car Racing</a></div>
				<div class="dLink" style="background:#004433;"><a href="http://www.unity-games.org/"><span style="font-size:8px;" class="bGame">[game]</span> Game OL Unity</a></div>
				<div class="dLink" style="background:#449922;"><a href="http://detik.com"><span style="font-size:8px;" class="bBerita">[berita]</span> Detik</a></div>
				<div class="dLink" style="background:#dd4422;"><a href="http://merdeka.com"><span style="font-size:8px;" class="bBerita">[berita]</span> Merdeka</a></div>
				<div class="dLink" style="background:#4400aa;"><a href="http://kompas.com"><span style="font-size:8px;" class="bBerita">[berita]</span> Kompas</a></div>
				<div class="dLink" style="background:#99aa00;"><a href="http://instagram.com"><span style="font-size:8px;" class="bSosial">[sosial]</span> Instagram</a></div>
				<div class="dLink" style="background:#3B5998;"><a href="http://facebook.com"><span style="font-size:8px;" class="bSosial">[sosial]</span> Facebook</a></div>
				<div class="dLink" style="background:#00ddcc;"><a href="http://twitter.com"><span style="font-size:8px;" class="bSosial">[sosial]</span> Twitter</a></div>
				<div class="dLink" style="background:#cc3300;"><a href="http://gmail.com"><span style="font-size:8px;" class="bEmail">[email]</span> Gmail</a></div>
				<div class="dLink" style="background:#772266;"><a href="http://mail.yahoo.com"><span style="font-size:8px;" class="bEmail">[email]</span> Yahoo Mail</a></div>
				<div class="dLink" style="background:#37aa22;"><a href="http://mail.com"><span style="font-size:8px;" class="bEmail">[email]</span> Mail</a></div>
				<div class="dLink" style="background:#123456;"><a href="http://hotmail.com"><span style="font-size:8px;" class="bEmail">[email]</span> Hotmail</a></div>
				<div class="dLink" style="background:#003388;"><a href="http://kompasiana.com"><span style="font-size:8px;" class="bBlog">[blog]</span> Kompasiana</a></div>
				<div class="dLink" style="background:#990000;"><a href="http://blogspot.com"><span style="font-size:8px;" class="bBlog">[blog]</span> Blogspot</a></div>
				<div class="dLink" style="background:#00aaaa;"><a href="http://wordpress.com"><span style="font-size:8px;" class="bBlog">[blog]</span> Wordpress</a></div>
				<div class="dLink" style="background:#443388;"><a href="http://www.aviantorichad.com"><span style="font-size:8px;" class="bBlog">[blog]</span> @aviantorichad</a></div>
				<div class="dLink" style="background:#dd5533;"><a href="http://www.tvonlineindonesia.net"><span style="font-size:8px;" class="bTv">[tv]</span> TV Online</a></div>
				<div class="dLink" style="background:#bb5599;"><a href="http://soundcloud.com"><span style="font-size:8px;" class="bMp3">[mp3]</span> Soundcloud</a></div>
				<div class="dLink" style="background:#556677;"><a href="http://stafaband.info"><span style="font-size:8px;" class="bMp3">[mp3]</span> Stafaband</a></div>
				<div class="dLink" style="background:#997766;"><a href="http://gudanglagu.co"><span style="font-size:8px;" class="bMp3">[mp3]</span> Gudang Lagu</a></div>
				<div class="dLink" style="background:#00ddff;"><a href="http://warungkost.com"><span style="font-size:8px;" class="bPulsa">[pulsa]</span> Warungkost</a></div>
				<div class="dLink" style="background:#dd00aa;"><a href="http://youtube.com"><span style="font-size:8px;" class="bVideo">[video]</span> Youtube</a></div>
				<div class="dLink" style="background:#aa0066;"><a href="http://keepvid.com"><span style="font-size:8px;" class="bVideo">[video]</span> Unduh Yutub Vid</a></div>
				<div class="dLink" style="background:#001040;"><a href="http://youtube-mp3.org"><span style="font-size:8px;" class="bVideo">[video]</span> Unduh Yutub MP3</a></div>
				<div class="dLink" style="background:#dd6699;"><a href="https://www.youtube.com/channel/UCxlP9Z8XyKHRpagVEin_0Rg/videos"><span style="font-size:8px;" class="bVideo">[video]</span> YT RTPapat.Net</a></div>
				<div class="dLink" style="background:#ddaa00;"><a href="http://server.rtpapat.net/RTPAPAT.NET/forum/"><span style="font-size:8px;">[forum]</span> Ngobrol RTPAPAT</a></div>
				<div class="dLink" style="background:#ddaa00;"><a href="http://kaskus.co.id"><span style="font-size:8px;" class="bForum">[forum]</span> Kaskus</a></div>
				<div class="dLink" style="background:#005555;"><a href="http://kelaskita.com"><span style="font-size:8px;" class="bForum">[forum]</span> KelasKita</a></div>
				<div class="dLink" style="background:#9388aa;"><a href="http://translate.google.co.id"><span style="font-size:8px;" class="bKamus">[kamus]</span> Google Translate</a></div>
				<div class="dLink" style="background:#55dd99;"><a href="http://tokopedia.com/warungkost"><span style="font-size:8px;" class="bToko">[toko]</span> Tokopedia</a></div>
				<div class="dLink" style="background:#aa1199;"><a href="http://bukalapak.com"><span style="font-size:8px;" class="bToko">[toko]</span> Bukalapak</a></div>
				<div class="dLink" style="background:#11ddcc;"><a href="http://olx.co.id"><span style="font-size:8px;" class="bToko">[toko]</span> OLX</a></div>
</div>