<script>
    function once_load() {
        
    }
    
    once_load();
</script>
<!--HEADER-->
<div class="header">
    <!--TITLE--><center style="margin-bottom:-20px;"><h1><span style="font-family:Arial;font-weight:bold;"><span style="color:#009988;">TENTANG</span> MIKROSTATOR</span></h1></center><!--END TITLE-->
    <!--DESCRIPTION--><!-- <center><h2><span style="font-size:11px;color:#008899;">..::: PENGGUNA RTPAPAT.NET :::...</span></h2></center> --><!--END DESCRIPTION-->
</div>
<div class="content">
    <b>MIKROSTATOR - Mikrotik Administrator</b>
    <ul>
    <li>Versi beta (Senin, 16 Mei 2016)</li>
    <li>Youtube : <a href="http://youtube.com/richadavianto" target="_blank">youtube.com/richadavianto</a></li>
    <li>Blog : <a href="http://mikrostator.aviantorichad.com" target="_blank">mikrostator.aviantorichad.com</a></li>
    <li>Email to : aviantorich@gmail.com</li>
    </ul>
    <p>MIKROSTATOR, sebuah aplikasi berbasis web yang dibuat berdasarkan kebutuhan untuk manajemen pengguna pada sebuah jaringan internet sederhana berbasis router MIKROTIK.</p>
    <h3>Change log</h3>
    <b>MIKROSTATOR versi beta (Senin, 16 Mei 2016):</b>
    <p>Komposisi:</p>
    <ul>
        <li>Mikrotik API PHP class (Denis Basta)</li>
        <li>Bootstrap</li>
        <li>PHP Framework CodeIgniter-2.2-stable</li>
        <li>Mysql</li>
        <li>Jquery</li>
    </ul>
    <p>Fitur:</p>
    <ul>
        <li>Tambah Jam</li>
        <li>Transfer Menit</li>
        <li>Real time user online (sesuai interval)</li>
        <li>Manajemen User</li>
        <li>Restore waktu/jam online ketika 'session time' te-Reset</li>
        <li>Log MIKROTIK</li>
        <li>Log MIKROSTATOR</li>
        <li>Kalkulator sederhana</li>
        <li>Auto Backup user online ke db</li>
        <li>Toggle Real time user online (sesuai interval)</li>
        <li>Toggle Auto Backup user online ke db</li>
        <li>Show User Profile</li>
        <li>Show DHCP Server Leases</li>
        <li>Delete Queue Simple</li>
        <li>Reboot & Shutdown Router</li>
        <li>Laporan harian, bulanan, tahunan, semua tahun</li>
        <li>Konfigurasi login router MIKROTIK</li>
        <li>Konfigurasi login MIKROSTATOR</li>
        <li>Tambah Transaksi lain</li>
        <li>Background MAC Address</li>
    </ul>
    <hr/>
    <b>MIKROSTATOR versi alpha 3 (Kamis, 07 Jan 2016):</b>
    <p>Komposisi:</p>
    <ul>
        <li>Mikrotik API PHP class (Denis Basta)</li>
        <li>Bootstrap</li>
        <li>PHP Native 'ala kadarnya'</li>
        <li>Mysql</li>
        <li>Jquery</li>
    </ul>
    <p>Fitur:</p>
    <ul>
        <li>Tambah Jam</li>
        <li>Transfer Menit</li>
        <li>Real time user online (sesuai interval)</li>
        <li>Manajemen User</li>
        <li>Restore waktu/jam online ketika 'session time' te-Reset</li>
        <li>Log MIKROTIK</li>
        <li>Log MIKROSTATOR</li>
        <li>Kalkulator sederhana</li>
        <li>Auto Backup user online ke db</li>
    </ul>
</div>